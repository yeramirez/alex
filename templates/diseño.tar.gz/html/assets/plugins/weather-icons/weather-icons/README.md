# Weather Icons
*Version Beta 1 - August 3rd 2013*

These are the Bootstrap ready Less files. Put the "weather-icons" folder inside your main Less folder and import it with the rest of your less imports.

**Remember** your CSS is going to look for the fonts in `./css`, a directory above. 